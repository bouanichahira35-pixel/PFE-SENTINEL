DATASET SENTINEL REALISTE - DONNEES SYNTHETIQUES POUR PFE

IMPORTANT:
Ces fichiers ne sont pas des donnees officielles ETAP.
Ils representent un historique realiste et coherent pour tester SENTINEL, alimenter le dashboard BI
et entrainer les modules d'aide a la decision.

Fichiers:
01_products_catalogue.csv             Catalogue de 650 produits industriels/petroliers.
02_suppliers.csv                      Fournisseurs realistes.
03_stocklots.csv                      Lots avec peremption, blocage ou quarantaine.
04_purchaseorders.csv                 Commandes fournisseurs.
05_stockentries.csv                   Historique des entrees stock.
06_stockexits.csv                     Historique des sorties stock.
07_requests.csv                       Demandes internes/externes.
08_inventories.csv                    Sessions d'inventaire.
09_aialerts.csv                       Alertes stock/risque.
10_notifications.csv                  Notifications metier.
11_stockout_training.csv              Dataset risque de rupture.
12_consumption_training_daily.csv     Dataset consommation quotidienne.
13_anomaly_training.csv               Dataset detection anomalies.
14_threshold_training.csv             Dataset seuil adaptatif.
15_decision_training.csv              Dataset aide a la decision.
16_dashboard_bi_daily.csv             Dataset indicateurs BI par jour.

Volumes:
Produits: 650
Entrees stock: 1569
Sorties stock: 32386
Demandes: 21281
Lots: 1128
Commandes fournisseurs: 2034
Inventaires: 180
Alertes: 547
Lignes consommation quotidienne: 44370
Lignes anomalies: 34045

Conseil:
- Importer les fichiers 01 a 10 si vous voulez remplir la base.
- Utiliser les fichiers 11 a 16 pour entrainer/tester les modeles et le dashboard BI.
